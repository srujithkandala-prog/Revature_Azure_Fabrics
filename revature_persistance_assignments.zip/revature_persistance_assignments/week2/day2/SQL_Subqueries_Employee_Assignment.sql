use day1;
create table Employees (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(100),
    Department VARCHAR(50),
    Salary DECIMAL(10,2),
    ManagerID INT,
    HireDate DATE
);
INSERT INTO Employees
(EmployeeID, EmployeeName, Department, Salary, ManagerID, HireDate)
VALUES
(101, 'John',    'Sales',   50000, 201, '2021-01-10'),
(102, 'Mary',    'Sales',   65000, 201, '2020-03-15'),
(103, 'David',   'HR',      55000, 202, '2022-05-20'),
(104, 'Sophia',  'HR',      70000, 202, '2019-07-18'),
(105, 'James',   'IT',      80000, 203, '2018-11-01'),
(106, 'Emma',    'IT',      75000, 203, '2021-09-25'),
(107, 'Michael', 'Finance', 90000, 204, '2017-06-12'),
(108, 'Olivia',  'Finance', 60000, 204, '2023-02-01');

select * from Employees;
-- 1. Find employees earning more than the average salary.

select * from Employees
where Salary>(select avg(Salary) 
from Employees);

-- 2. Find employees earning the highest salary.

select * from Employees
where Salary>=(select max(Salary) 
from Employees);

--  Find employees earning the second highest salary.

SELECT *
FROM Employees
WHERE Salary = (
    SELECT MAX(Salary)
    FROM Employees
    WHERE Salary < (
        SELECT MAX(Salary)
        FROM Employees
    )
);

-- 4. List employees whose salary is less than the maximum salary.

select * from Employees
where Salary<(select max(Salary) 
from Employees);

-- 5. Find employees working in the same department as the employee with the highest salary.

SELECT *
FROM Employees
WHERE Department = (
    SELECT Department
    FROM Employees
    WHERE Salary = (
        SELECT MAX(Salary)
        FROM Employees
    )
);
-- 6. Find departments having employees with salary greater than 70,000.

select distinct Department
from Employees
where Salary>70000;

-- 7. Find employees whose salary is above their department average salary

SELECT *
FROM Employees e
WHERE Salary > (
    SELECT AVG(Salary)
    FROM Employees
    WHERE Department = e.Department
);

-- 8. Find employees who earn more than all employees in the HR department.
SELECT *
FROM Employees
WHERE Salary > (
    SELECT MAX(Salary)
    FROM Employees
    WHERE Department = 'HR'
);

-- 9. Find employees whose salary matches any salary in the Sales department.
SELECT *
FROM Employees
WHERE Salary IN (
    SELECT Salary
    FROM Employees
    WHERE Department = 'Sales'
);

-- 10. Find employees hired after the employee with the lowest salary.
select * 
from Employees
where HireDate>(select HireDate
from Employees
where Salary=(select min(Salary)
from Employees));

-- 11. Find the department with the highest average salary.
SELECT Department
FROM Employees
GROUP BY Department
HAVING AVG(Salary) = (
    SELECT MAX(AvgSalary)
    FROM (
        SELECT AVG(Salary) AS AvgSalary
        FROM Employees
        GROUP BY Department
    ) AS DeptAvg
);

-- 12. Find employees who earn the minimum salary in their department.

SELECT *
FROM Employees e
WHERE Salary = (
    SELECT MIN(Salary)
    FROM Employees
    WHERE Department = e.Department
);

-- 13. Display managers who manage employees earning more than 75,000.
select distinct ManagerID
from Employees
where Salary >75000;

-- 14. Find employees whose salary is greater than their manager's salary (assume managers are employees).
SELECT e.EmployeeName,
       e.Salary,
       m.EmployeeName AS ManagerName,
       m.Salary AS ManagerSalary
FROM Employees e
JOIN Employees m
ON e.ManagerID = m.EmployeeID
WHERE e.Salary > m.Salary;

-- 15. Find the top 3 highest paid employees using a subquery.

SELECT *
FROM (
    SELECT *,
           DENSE_RANK() OVER (ORDER BY Salary DESC) AS rnk
    FROM Employees
) t
WHERE rnk <= 3;